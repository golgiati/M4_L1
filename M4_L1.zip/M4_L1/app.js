const express = require('express');
const app = express();
const port = 3000;

// routes
const studentRoutes = require('./routes/studentRoutes');
app.use('/students', studentRoutes);

// send a message to root
app.get('/', (req, res) => {
    res.send('Root');
});

// const mongoose = require('mongoose');
// mongoose.connect('mongodb+srv://golgiati:Password1@cluster0.qwk7kvt.mongodb.net/studentsDB');

// // check for connection
// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error...'));
// db.once('open', function() {
//     console.log('Connection to database successful!');
// });

// start the server
app.listen(port, () => { console.log(`App running on port ${port}...`) });