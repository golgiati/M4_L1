// Student Controller

const Student = require('../models/studentModel');

// Retrieve all data from database
exports.getAllStudents = async (req, res) => {
    // const students = Student.find()

    // try {
    //     res.status(200).json({
    //         status: 'Success',
    //         results: students.length,
    //         data: {
    //             students
    //         }
    //     });
    // } catch (err) {
    //     res.status(404).json({
    //         status: 'fail',
    //         message: err
    //     });

    // }
    res.send('Hello from /students GET');
}

// Retrieve data by ID
exports.getStudentById = async (req, res) => {
    // const {id} = req.params;
    // const students = Student.find({_id: id});

    // try {
    //     res.status(200).json({
    //         status: 'Success',
    //         results: students.length,
    //         data: {
    //             students
    //         }
    //     });
    // } catch (err) {
    //     res.status(404).json({
    //         status: 'fail',
    //         message: err
    //     });
    // }
    res.send('Hello from /student/:id GET');
}

// Save data to database
exports.addNewStudent = async (req, res) => {
    // const newStudent = req.body;
    // const student = await Student.create(newStudent);
    
    // res.status(201).json({
    //     status: 'Success',
    //     data: student
    // });
    res.send('Hello from /student POST');
};

exports.editStudentById = (req, res) => {
     res.send('Hello Word! from /student/:id PUT'); 
}

exports.patchStudentById = (req, res) => {
     res.send('Hello Word! from /student/:id PATCH'); 
}

exports.deleteStudentById = (req, res) => {
     res.send('Hello Word! from /student:/id DELETE'); 
}