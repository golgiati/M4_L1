const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));

// Set the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Set the routes
const studentRoute = require('./routes/studentRoutes');
app.use('/students', studentRoute);

// Start the server
app.listen(3000, () => { console.log('Server running on port 3000') });