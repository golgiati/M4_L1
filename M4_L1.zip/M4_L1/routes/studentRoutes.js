// App routes

const express = require('express');
const router = express.Router();

// specify the controller for student CRUD
const studentController = require('../controllers/studentController');

router.route('/')
    .get(studentController.getAllStudents);

// specify the routes for CRUD without ID
router.route('/new')
    .post(studentController.addNewStudent);

// specify the routes for CRUD with ID
router.route('/:id')
    .get(studentController.getStudentById)
    .put(studentController.editStudentById)
    .patch(studentController.patchStudentById)
    .delete(studentController.deleteStudentById);

// export the routes
module.exports = router;
