// Student controllers

let students = [];

// Get the data form
exports.getDataForm = async (req, res) => {
    res.render('index', { students: students });
}

// Post the data to the database
exports.postDataForm = async (req, res) => {
    let date = new Date();
    students.push(req.body);
    console.log('Student added to database', date.toISOString());
    res.redirect('/students');
}